package com.example.customers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomersApplicationTests {

	@Test
	void contextLoads() {
	}

}
